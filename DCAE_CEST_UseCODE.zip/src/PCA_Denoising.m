function Z_denoised =PCA_Denoising(IMAG_CEST, roi_brain_all)
%% Tutorial for adaptive denoising
% Small script to show the denoising of CEST data using different criteria
% to determine the optimal number of components to retain.
%
% Reference:
%   Breitling J, Deshmane A, Goerke S, Korzowski A, Herz K, Ladd ME,
%   Scheffler K, Bachert P, Zaiss M. Adaptive denoising for chemical
%   exchange saturation transfer MR imaging. NMR Biomed. (2019);32:e4133.

%% Load example dataset:
%   Z_noise: Motion corrected, normalized and B0-corrected dataset acquired
%            at 7T in a healthy volunteer
%        dw: Frequency offsets for the Z-spectra
%   Segment: Manual segmentation of the parenchym 


% create frequency offset
maxf=2000;
step=50;

offset= -maxf:step:maxf;
k_9p4T=[-4000, -3500, -3000, -2500, offset, 2500, 3000,3500,4000];
dw=k_9p4T'/400;
Cest_InVivoD = zeros(89, 3395);
for rt= 1:1
for i = 1:1
Z_noise1= IMAG_CEST(:,:,:); 
Segment1 = roi_brain_all;
if i==1; sz2(rt) = length(find(Segment1));end
if rt==1; sz=0; end 
if rt>1; sz = sz2(rt-1); end
[Z_denoised(:,:,89*(i-1)+1:89*i),k, Xd(89*(i-1)+1:89*i,:)]= AdaptiveDenoising(Z_noise1,Segment1,'Median',true);
Z_denoised(Z_denoised==NaN)=0;
end
end
end

% %% Plot example Z-spectra
% voxel = [30,30,1]; % Set voxel location
% figure(i), hold on
% plot(dw,squeeze(Z_noise1(voxel(1),voxel(2),:)),'.-','color','r');
% plot(dw,squeeze(Z_denoised(voxel(1),voxel(2),89*(i-1)+1:89*i)),'.-','color','k');
% xlim([-10 10]);
% ylim([0 1]);
% box on;
% set(gca,'xdir','reverse');
% xlabel('\Delta\omega [ppm]')
% ylabel('Z')
% legend({'noisy','denoised'})
% hold off
% Xd1= Xd;
% end
% clear Z_denoised
% if rt==1
% Cest_InVivoD(:,1:sz2(rt)) = Xd1;
% end
% if rt>1
% szs = sum(sz2(1:rt-1))
% Cest_InVivoD(:,szs+1:szs+sz2(rt)) = Xd1;
% end
% clear Xd
% end
% %%
% clearvars -except Cest_InVivoD
% C2= Cest_InVivoD';
% %save('PCA_DenoisedR1.mat','C2')
