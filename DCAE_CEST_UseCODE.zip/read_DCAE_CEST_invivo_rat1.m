function read_DCAE_invivo_rat2
tic
clear;
% this sample code has data with one power of 1uT at 4.7

wwww=[0.5, 1]; % we take www(2) for 1uT
addpath src\
addpath fns\
%%
iter = 2 % 1, 3 or 5  %% Iterations for Context Learning 
if iter==1; load('DCAECEST_Fitted_rat11p01CLIter.mat'); end
if ~exist('A','var');

%% % x include the frequency offset.
TE=0.028;

x=[  -2000	-1750	-1500	-1250	-1000	-975	-950	-925	-900	-875	-850	-825	-800 ...
    -775	-750	-725	-700	-675	-650	-625	-600	-575	-550	-525	-500	-475 ...
    -450	-425	-400	-375	-350	-325	-300	-275	-250	-225	-200	-175	-150 ...
    -125	-100	-75	-50	-25	0	25	50	75	100	125	150	175	200	225	250	275	300	325	350	375	400	425	 ...
    450	475	500	525	550	575	600	625	650	675	700	725	750	775	800	825	850	875	900	925	950	975	1000	1250 ...
    1500	1750	2000];  % Hz

rat_amount=6;   rat_number=1;   rat_time=1;  rat_power=2;

load('rat1/roi_brain.mat');

costh2=x.^2./((wwww(rat_power)*42.6).^2+x.^2);
R1W_map=R1fmap;
R1fmap=1./sirT1map*1000;

tumor_size(rat_number)=sum(sum(roi_brain_tumor));
normal_size(rat_number)=sum(sum(roi_brain_normal1));
%%
number=90
for i=1:1:number
    % read Z-spectrum
    [MI(:,:,i)]=double(load_fdf('rat1/CW_1uT',i)*100);
end
%% Read Structural image
Struct_rat1(:,:)=double(load_fdf('rat1/CW_1uT',90)*100);
%% Normalize Z-spectrum using the structural image
for i=1:1:number-1
    IMAG_tumorEST_final(:,:,i)=MI(:,:,i)./MI(:,:,number).*roi_brain(:,:);
end

% Define variable images to store data
mor_image_water(64,64)=0;
mor_dir_image_water(64,64)=0;

mor_image_amide(64,64)=0;
mor_dir_image_amide(64,64)=0;
mor_dir2_image_amide(64,64)=0;

mor_image_NOE3p5(64,64)=0;
mor_dir_image_NOE3p5(64,64)=0;
mor_dir2_image_NOE3p5(64,64)=0;

Zspectra_simu_water(64,64,89)=0;
Zspectra_simu_ref_water(64,64,89)=0;
Mfinf
Zspectra_simu_amide(64,64,89)=0;
Zspectra_simu_ref_amide(64,64,89)=0;

Zspectra_simu_NOE3p5(64,64,89)=0;
Zspectra_simu_ref_NOE3p5(64,64,89)=0;

IM3P(64,64)=0;
IM3PF(64,64)=0;
IM3PFe(64,64)=0;

Zspectra_mor_amide(64,64,89,1,4,rat_amount)=0;
Zspectra_mor_NOE3p5(64,64,89,1,4,rat_amount)=0;
Zspectra_dir_amide(64,64,89,1,4,rat_amount)=0;
Zspectra_dir_NOE3p5(64,64,89,1,4,rat_amount)=0;

Zspectra_dir2_amide(64,64,89,1,4,rat_amount)=0;
Zspectra_dir2_NOE3p5(64,64,89,1,4,rat_amount)=0;
image_simu_ref_amide(64,64,1,3,rat_amount)=0;
image_simu_ref_NOE3p5(64,64,1,3,rat_amount)=0;

Amide_fitted(64,64,89)  =0;
Amide_fitted_N(64,64,89) = 0;Amide_fitted_T(64,64,89) = 0;
NOE3p5_fitted(64,64,89)  =0;
NOE3p5_fitted_N(64,64,89) = 0;NOE3p5_fitted_T(64,64,89) = 0;

wc(64,64)=0;
adc(64,64)=0;
Zspectra1_simu_amide(64,64,rat_amount)=0;
IMA_tmp(64,64,89)=0;

simu_ref_amide(64,64)=0;
simu_ref_NOE3p5(64,64)=0;

IMA1(64,64,89)=0;
% %  3*3 filter Gaussian if needed
for ii=1:1:number-1
    IMA(:,:,ii)=medfilt2(IMAG_tumorEST_final(:,:,ii),[1 1]);
end

%%
% ***** Applying the MLSVD filter for denosing   % 362 Z-sectrums in rat#3

% [Ue, Se] = lmlra(IMA,[10,10,5]);
% IMAMLSVD =lmlragen(Ue, Se); % IMAMLSVD is the Denoised Signal form the MLSVD Method 

%% NLmCED
%****** Applying NLmCED filter for denoising ******%
%%% rho and alpha are the optimised parameters for the CEST data (synthetic and invivo);
%%%  If you are using another modality you can chage these parameter to optimise the denoising process
% addpath NLmCED_Filter/
% iter1=param.iter1 ;
% wind= param.wind;
% rho = 0.001;
% alpha = 0.001;
% IMA_denoisedNLmCED = NLmCED(IMA,iter1,rho, alpha,wind); % IMA_denoisedNLmCED is the Denoised Signal form the NLmCED Method
%%
% PCA Application
% %****** Applying PCA for denoising the Z-spectrum ******%
addpath PCA_denoising/
IMAP= PCA_Denoising(IMA,roi_brain); % IMAP is the PCA denoised signal
%%
XX =64;YY=64;
for ai=1:1:XX
    for   aj=1:1:YY

        for kk=1:1:number-1
            FIM(kk)=IMAP(ai,aj,number-kk);%number-kk
        end

        if FIM(1)==0

            IM11(ai,aj)=0;
            IM12(ai,aj)=0;
            IM13(ai,aj)=0;
            IM21(ai,aj)=0;
            IM22(ai,aj)=0;
            IM23(ai,aj)=0;
            IM31(ai,aj)=0;
            IM32(ai,aj)=0;
            IM33(ai,aj)=0;
            IM41(ai,aj)=0;
            IM42(ai,aj)=0;
            IM43(ai,aj)=0;
            IM51(ai,aj)=0;
            IM52(ai,aj)=0;
            IM53(ai,aj)=0;
            IM61(ai,aj)=0;
            IM62(ai,aj)=0;
            IM63(ai,aj)=0;

        else

            sig=(1-FIM);

            IMA_tmp(ai,aj,1:number-1)= 1-sig;

            % beta0=[A, b]
            beta0= [0.9, 0/2, 560/2,               0.025, -1400/2, 200/2,        0.01, -800/2, 600/2,        0.001, 600/2, 400/2,          0.02, 1400/2, 1200/2,          0.1, 0/2, 10000/2]; % initial test
            lb=[0.02, -400/2, 120/2,               0, -1600/2, 160/2,             0, -1200/2, 200/2,           0, 400/2, 0/2,                0, 1000/2, 400/2,            0, -1600/2, 4000/2]; % lower bound
            ub=[1, 400/2,4000/2,                    0.2, -1200/2, 1200/2,          0.2,-400/2, 2000/2,         0.2, 800/2, 600/2,            1, 1800/2, 2000/2,         1, 1600/2, 40000/2]; % upper bound

            % Delta =[sep; R1S; R1W; R1M; R2M; mnotw];

            Delta=[1]; % constants

            options=optimset('lsqcurvefit') ;
            options = optimset('Display','off','TolFun',1e-8,'TolX',1e-8,'MaxFunEvals',5e4*length(x),'MaxIter',2e5) ;

            [beta,resnorm,residual,exitflag,output,lambda,jacobian] = ...
                lsqcurvefit(@matsolv, beta0, x, sig, lb, ub, options, Delta) ;


            sig_simu=matsolv(beta,x,Delta);


            IM11(ai,aj)=beta(1);
            IM12(ai,aj)=beta(2);
            IM13(ai,aj)=beta(3);
            IM21(ai,aj)=beta(4);
            IM22(ai,aj)=beta(5);
            IM23(ai,aj)=beta(6);
            IM31(ai,aj)=beta(7);
            IM32(ai,aj)=beta(8);
            IM33(ai,aj)=beta(9);
            IM41(ai,aj)=beta(10);
            IM42(ai,aj)=beta(11);
            IM43(ai,aj)=beta(12);
            IM51(ai,aj)=beta(13);
            IM52(ai,aj)=beta(14);
            IM53(ai,aj)=beta(15);
            IM61(ai,aj)=beta(16);
            IM62(ai,aj)=beta(17);
            IM63(ai,aj)=beta(18);


            % water
            beta_water=beta;
            sig_simur_water=matsolv(beta_water,x,Delta);
            beta_water(4)=0;
            beta_water(7)=0;
            beta_water(10)=0;
            beta_water(13)=0;
            beta_water(16)=0;
            sig_simur_ref_water=matsolv(beta_water,x,Delta);

        
            for nn=1:1:number-1
                Zspectra_simu_water(ai,aj,nn)=sig_simur_water(nn);
                Zspectra_simu_ref_water(ai,aj,nn)=sig_simur_ref_water(nn);
                Zspectra_mor_water(ai,aj,nn,rat_time,rat_power, rat_number)=sig_simur_ref_water(nn);
            end

            % amide

            beta_amide=beta;
            sig_simur_amide=matsolv(beta_amide,x,Delta);
            beta_amide(4)=0;
            sig_simur_ref_amide=matsolv(beta_amide,x,Delta);

            mor_amide=(1./(1-sig_simur_amide)-1./(1-sig_simur_ref_amide));
            mor_dir_amide=(sig_simur_amide-sig_simur_ref_amide);
            mor_dir2_amide=((1-sig_simur_ref_amide)-(1-sig_simur_amide))./(1-sig_simur_ref_amide);

            for nn=1:1:number-1
                Zspectra_simu_amide(ai,aj,nn)=sig_simur_amide(nn);
                Zspectra1_simu_amide(ai,aj,nn)=1-sig_simur_amide(nn);
                Zspectra_simu_ref_amide(ai,aj,nn)=sig_simur_ref_amide(nn);
                Zspectra_mor_amide(ai,aj,nn,rat_time,rat_power, rat_number)=mor_amide(nn);
                Zspectra_dir_amide(ai,aj,nn,rat_time,rat_power, rat_number)=mor_dir_amide(nn);
                Zspectra_dir2_amide(ai,aj,nn,rat_time,rat_power, rat_number)=mor_dir2_amide(nn);
            end

            mor_image_amide(ai,aj)=max(mor_amide(15:19)); %13:21 % 17
            mor_dir_image_amide(ai,aj)=max(mor_dir_amide(15:19)); %13:21
            mor_dir2_image_amide(ai,aj)=max(mor_dir2_amide(15:19)); % 13:21

            simu_ref_amide(ai,aj)=sig_simur_ref_amide(17);
            %
            Amide_fitted(ai,aj,:) = mor_amide(1:89)*roi_brain(ai,aj);

            Amide_fitted_N(ai,aj,:) = mor_amide(1:89)*roi_brain_normal1(ai,aj);
            Amide_fitted_T(ai,aj,:) = mor_amide(1:89)*roi_brain_tumor(ai,aj);

            % NOE3p5
            beta_NOE3p5=beta;
            sig_simur_NOE3p5=matsolv(beta_NOE3p5,x,Delta);
            beta_NOE3p5(13)=0;
            sig_simur_ref_NOE3p5=matsolv(beta_NOE3p5,x,Delta);

            mor_NOE3p5=(1./(1-sig_simur_NOE3p5)-1./(1-sig_simur_ref_NOE3p5));
            mor_dir_NOE3p5=(sig_simur_NOE3p5-sig_simur_ref_NOE3p5);
            mor_dir2_NOE3p5=((1-sig_simur_ref_NOE3p5)-(1-sig_simur_NOE3p5))./(1-sig_simur_ref_NOE3p5);

            for nn=1:1:number-1
                Zspectra_simu_NOE3p5(ai,aj,nn)=sig_simur_NOE3p5(nn);
                Zspectra_simu_ref_NOE3p5(ai,aj,nn)=sig_simur_ref_NOE3p5(nn);
                Zspectra_mor_NOE3p5(ai,aj,nn,rat_time,rat_power, rat_number)=mor_NOE3p5(nn);
                Zspectra_dir_NOE3p5(ai,aj,nn,rat_time,rat_power, rat_number)=mor_dir_NOE3p5(nn);
                Zspectra_dir2_NOE3p5(ai,aj,nn,rat_time,rat_power, rat_number)=mor_dir2_NOE3p5(nn);
            end

            mor_image_NOE3p5(ai,aj)=max(mor_NOE3p5(69:77)); % 69:77 % 73
            mor_dir_image_NOE3p5(ai,aj)=max(mor_dir_NOE3p5(69:77)); % 69:77
            mor_dir2_image_NOE3p5(ai,aj)=max(mor_dir2_NOE3p5(69:77)); % 69:77


            simu_ref_NOE3p5(ai,aj)=sig_simur_ref_NOE3p5(72);

            NOE3p5_fitted(ai,aj,:) = mor_NOE3p5(1:89)*roi_brain(ai,aj);
            NOE3p5_fitted_N(ai,aj,:) = mor_NOE3p5(1:89)*roi_brain_normal1(ai,aj);
            NOE3p5_fitted_T(ai,aj,:) = mor_NOE3p5(1:89)*roi_brain_tumor(ai,aj);

        end
    end
    ai
end
% end
%%
IMAOrig = IMA;
IMA = IMA_tmp;
% amide signal in tumor and normal tissue
for k=1:1:89
    Zspectra_tumor(k, rat_time, rat_power, rat_number)=sum(sum(IMA(:,:,k).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_normal(k, rat_time, rat_power, rat_number)=sum(sum(IMA(:,:,k).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra(k, rat_time, rat_power, rat_number)=sum(sum(IMA(:,:,k).*roi_brain))./sum(sum(roi_brain));
    Zspectra_residual_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra1_simu_amide(:,:,k).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_residual_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra1_simu_amide(:,:,k).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    IMA_tempN = IMA(:,:,k).*roi_brain_normal1; IMA_tempN(IMA_tempN==0)=nan;
    IMA_tempT = IMA(:,:,k).*roi_brain_tumor; IMA_tempT(IMA_tempT==0)=nan;

    Zspectra_tumor_std(k, rat_time, rat_power, rat_number)=std(std(IMA_tempT,'omitnan'),'omitnan');
    Zspectra_normal_std(k, rat_time, rat_power, rat_number)=std(std(IMA_tempN,'omitnan'),'omitnan');

end

for k=1:1:89
    Zspectra_mor_amide_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_amide(:,:,k, rat_time,rat_power,  rat_number).*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_mor_amide_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_amide(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_mor_amide_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_amide(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));
    Zspectra_mor_amideN = Zspectra_mor_amide(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_normal1; Zspectra_mor_amideN(Zspectra_mor_amideN==0)=nan;
    Zspectra_mor_amideT = Zspectra_mor_amide(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor; Zspectra_mor_amideT(Zspectra_mor_amideT==0)=nan;

    AptFZspectra_tumor_std(k)=1.2*std(std(Zspectra_mor_amideT,'omitnan'),'omitnan');
    AptFZspectra_normal_std(k)=1.2*std(std(Zspectra_mor_amideN,'omitnan'),'omitnan');

end

%%
for k=1:1:89
    Zspectra_mor_NOE3p5_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_mor_NOE3p5_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_mor_NOE3p5_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));

    Zspectra_mor_NOE3p5N = Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1;
    Zspectra_mor_NOE3p5N(Zspectra_mor_NOE3p5N==0)=nan;
    Zspectra_mor_NOE3p5T = Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain_tumor;
    Zspectra_mor_NOE3p5T(Zspectra_mor_NOE3p5T==0)=nan;

    NOEFZspectra_tumor_std(k)=1.2*std(std(Zspectra_mor_NOE3p5T,'omitnan'),'omitnan');
    NOEFZspectra_normal_std(k)=1.2*std(std(Zspectra_mor_NOE3p5N,'omitnan'),'omitnan');

end
%%
for k=1:1:89
    Zspectra_simu_ref_amide_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_amide(:,:,k).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_simu_ref_amide_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_amide(:,:,k).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_simu_ref_amide_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_amide(:,:,k).*roi_brain))./sum(sum(roi_brain));
end

for k=1:1:89
    Zspectra_simu_ref_NOE3p5_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_NOE3p5(:,:,k).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_simu_ref_NOE3p5_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_NOE3p5(:,:,k).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_simu_ref_NOE3p5_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_NOE3p5(:,:,k).*roi_brain))./sum(sum(roi_brain));
end

for k=1:1:89
    Zspectra_dir_amide_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_amide(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_dir_amide_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_amide(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_dir_amide_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_amide(:,:,k, rat_time, rat_power, rat_number).*roi_brain))./sum(sum(roi_brain));
end

for k=1:1:89
    Zspectra_dir_NOE3p5_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_NOE3p5(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_dir_NOE3p5_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_dir_NOE3p5_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain))./sum(sum(roi_brain));
end

for k=1:1:89
    Zspectra_dir2_amide_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_amide(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_dir2_amide_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_amide(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_dir2_amide_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_amide(:,:,k, rat_time, rat_power, rat_number).*roi_brain))./sum(sum(roi_brain));
end

for k=1:1:89
    Zspectra_dir2_NOE3p5_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_NOE3p5(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_dir2_NOE3p5_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_dir2_NOE3p5_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain))./sum(sum(roi_brain));
end

AREX_image_dir_amide(:,:, rat_time, rat_power, rat_number) =mor_dir_image_amide.*roi_brain;
AREX_image_dir_NOE3p5(:,:, rat_time, rat_power, rat_number) =mor_dir_image_NOE3p5.*roi_brain;

AREX_image_mor_amide(:,:, rat_time, rat_power, rat_number) =mor_image_amide.*R1fmap.*(1+0).*roi_brain;
AREX_image_mor_NOE3p5(:,:, rat_time, rat_power, rat_number) =mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain;

AREX_image_mor_amide_watercontent(:,:, rat_time, rat_power, rat_number) =mor_image_amide.*R1fmap.*(1+0).*roi_brain.*Mfinf;
AREX_image_mor_NOE3p5_watercontent(:,:, rat_time, rat_power, rat_number) =mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain.*Mfinf;

AREX_image_mor_noR1correction_amide(:,:, rat_time, rat_power, rat_number) =mor_image_amide.*roi_brain;
AREX_image_mor_noR1correction_NOE3p5(:,:, rat_time, rat_power, rat_number) =mor_image_NOE3p5.*roi_brain;

Value_AREX_image_mor_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_AREX_image_mor_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));

Value_AREX_image_mor_amide(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));
Value_AREX_image_mor_NOE3p5(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));

Value_AREX_image_mor_amide_tumor_watercontent(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*Mfinf.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_AREX_image_mor_NOE3p5_tumor_watercontent(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*Mfinf.*roi_brain_tumor))./sum(sum(roi_brain_tumor));

Value_AREX_image_mor_noR1correction_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_AREX_image_mor_noR1correction_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*roi_brain_tumor))./sum(sum(roi_brain_tumor));

Value_AREX_image_mor_amide_normal_watercontent(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*Mfinf.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_AREX_image_mor_NOE3p5_normal_watercontent(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*Mfinf.*roi_brain_normal1))./sum(sum(roi_brain_normal1));

Value_AREX_image_mor_amide_normal(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_AREX_image_mor_NOE3p5_normal(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain_normal1))./sum(sum(roi_brain_normal1));

Value_AREX_image_mor_noR1correction_amide_normal(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_AREX_image_mor_noR1correction_NOE3p5_normal(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*roi_brain_normal1))./sum(sum(roi_brain_normal1));

Value_AREX_image_mor_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_AREX_image_mor_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));

Value_AREX_image_mor_amide(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));
Value_AREX_image_mor_NOE3p5(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));

MTR_image_dir2_amide(:,:, rat_time, rat_power, rat_number) =mor_dir2_image_amide.*roi_brain;
MTR_image_dir2_NOE3p5(:,:, rat_time, rat_power, rat_number) =mor_dir2_image_NOE3p5.*roi_brain;

Value_MTR_image_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_amide.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_MTR_image_amide_normal(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_amide.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_MTR_image_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_NOE3p5.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_MTR_image_NOE3p5_normal(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_NOE3p5.*roi_brain_normal1))./sum(sum(roi_brain_normal1));

Value_MTR_image_amide(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_amide.*roi_brain))./sum(sum(roi_brain));
Value_MTR_image_NOE3p5(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_NOE3p5.*roi_brain))./sum(sum(roi_brain));
Value_MTR2_image_amide(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_amide.*roi_brain))./sum(sum(roi_brain));
Value_MTR2_image_NOE3p5(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_NOE3p5.*roi_brain))./sum(sum(roi_brain));

Value_MTR2_image_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_amide.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_MTR2_image_amide_normal(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_amide.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_MTR2_image_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_NOE3p5.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_MTR2_image_NOE3p5_normal(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_NOE3p5.*roi_brain_normal1))./sum(sum(roi_brain_normal1));

value_R1fmap_tumor(rat_number)=sum(sum(R1fmap.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
value_R1fmap_normal(rat_number)=sum(sum(R1fmap.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
value_R1fmap(rat_number)=sum(sum(R1fmap.*roi_brain))./sum(sum(roi_brain));
value_pmfmap_tumor(rat_number)=sum(sum(pmfmap.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
value_pmfmap_normal(rat_number)=sum(sum(pmfmap.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
value_pmfmap(rat_number)=sum(sum(pmfmap.*roi_brain))./sum(sum(roi_brain));
value_kmfmap_tumor(rat_number)=sum(sum(kmfmap.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
value_kmfmap_normal(rat_number)=sum(sum(kmfmap.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
value_kmfmap(rat_number)=sum(sum(kmfmap.*roi_brain))./sum(sum(roi_brain));
value_Mfinf_tumor(rat_number)=sum(sum(Mfinf.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
value_Mfinf_n_brormal(rat_number)=sum(sum(Mfinf.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
value_Mfinf(rat_number)=sum(sum(Mfinf.*roi_brain))./sum(sum(roi_brain));

image_simu_ref_amide(:,:, rat_time, rat_power, rat_number)=simu_ref_amide;
image_simu_ref_NOE3p5(:,:, rat_time, rat_power, rat_number)=simu_ref_NOE3p5;

value_R1Wmap_tumor(rat_number)=sum(sum(R1W_map.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
value_R1Wmap_normal(rat_number)=sum(sum(R1W_map.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
value_R1Wmap(rat_number)=sum(sum(R1W_map.*roi_brain))./sum(sum(roi_brain));

%%
% A_PCA= 100*mor_image_amide.*roi_brain.*(R1fmap);
A_PCA = 100*AREX_image_mor_amide(:,:,1,2);
AMD_PCA= A_PCA;
AMD_PCA(A_PCA==0)=nan;
AMD_mean_PCA= mean(mean(AMD_PCA,'omitnan'),'omitnan');
AMD_std_PCA= std(std(AMD_PCA,'omitnan'),'omitnan');

B_PCA =100*AREX_image_mor_NOE3p5;%mor_image_NOE3p5.*roi_brain.*R1fmap;
NOE_PCA = B_PCA;
NOE_PCA(B_PCA==0)=nan;
NOE_mean_PCA= mean(mean(NOE_PCA,'omitnan'),'omitnan');
NOE_std_PCA= std(std(NOE_PCA,'omitnan'),'omitnan');

Amide_fitted_PCA = Zspectra_mor_amide_all(:,1,rat_power);

NOE3p5_fitted_PCA = Zspectra_mor_NOE3p5_all(:,1,rat_power);

%%
% A= 100*(mor_image_amide.*roi_brain).*R1fmap;%
A =100*AREX_image_mor_amide(:,:,1,2);
A1 = imcrop(A,[16 17 28 19]); 

% ax=figure; imagesc(A1); axis off; c=colorbar('FontSize',18); caxis([0, 10]);
c=colorbar('FontSize',18);axis off;
w = c.LineWidth;  c.LineWidth = 1.5;
% exportgraphics(ax,[pwd '/outputs/Amiderat11p0_PCA23.png'],'Resolution',300)
%%
B =100*AREX_image_mor_NOE3p5(:,:,1,2);
B1= imcrop(B,[16 17 28 19]);
ax=figure;imagesc(B1);axis off; colorbar;caxis([0, 25]);
c=colorbar('FontSize',18);axis off;
w = c.LineWidth;
c.LineWidth = 1.5;

% exportgraphics(ax,[pwd '/outputs/NOE3p5Maprat11p0_PCA23.png'],'Resolution',300)
%%

ATum = A.*roi_brain_tumor;
ANor = A.*roi_brain_normal1;
AROINT= ANor+ATum;
rat1_Amide1p0T= ATum; rat1_Amide1p0N= ANor;
ATum(ATum==0)=nan;ANor(ANor==0)=nan;
mean_Tum= mean(mean(ATum,'omitnan'),'omitnan')
std_Tum= std(std(ATum,'omitnan'),'omitnan')
mean_Nor= mean(mean(ANor,'omitnan'),'omitnan')
std_Nor= std(std(ANor,'omitnan'),'omitnan')

B = AREX_image_mor_NOE3p5(:,:,1,2);
NOETum =B.*roi_brain_tumor;
NOENor = B.*roi_brain_normal1;
rat1_NOE1P0T= NOETum; rat1_NOE1P0N= NOENor;
ROINT= NOENor+NOETum;
NOETum(NOETum==0)=nan;NOENor(NOENor==0)=nan;
mean_TumNOE= mean(mean(NOETum.*roi_brain_tumor,'omitnan'),'omitnan')
std_TumNOE= std(std(NOETum.*roi_brain_tumor,'omitnan'),'omitnan')
mean_NorNOE= mean(mean(NOENor.*roi_brain_normal1,'omitnan'),'omitnan')
std_NorNOE= std(std(NOENor.*roi_brain_normal1,'omitnan'),'omitnan')

%% 
str = 'rat1';
APT_PCA23 =  sscanf(str,'rat%d')
%
T2 = table(APT_PCA23, 1*mean_Nor, 1*std_Nor,1*mean_Tum, 1*std_Tum, 1*mean_NorNOE, 1*std_NorNOE,1*mean_TumNOE, 1*std_TumNOE)
% writetable(T2,'Invivo_New1p0.xlsx','Sheet','PCA23up','WriteMode','append')

    
%%
% cc
clearvars -except x AMD_mean_PCA NOE_mean_PCA Amide_fitted_PCA NOE3p5_fitted_PCA AMD_std_PCA NOE_std_PCA IMAP IMAMLSVD A_PCA B_PCA iter
toc
%%  %% DCAE_Fitting
tic
% these data have four power of 0.5uT, 1uT, 2uT, and 3uT at 4.7
% x include the frequency offset.
wwww=[0.5, 1]; % we take www(2) for 1uT

TE=0.028;   rat_amount=6;  rat_number=1;  rat_time=1;  rat_power=2;

load('rat1/roi_brain.mat');

costh2=x.^2./((wwww(rat_power)*42.6).^2+x.^2);
R1W_map=R1fmap;
R1fmap=1./sirT1map*1000;

tumor_size(rat_number)=sum(sum(roi_brain_tumor));
normal_size(rat_number)=sum(sum(roi_brain_normal1));


%%
number=90
for i=1:1:number
    % read Z-spectrum
    [MI(:,:,i)]=double(load_fdf('rat1/CW_1uT',i)*100);
end
%% Read Structural image
Struct_rat1(:,:)=double(load_fdf('rat1/CW_1uT',90)*100);
%% Normalize Z-spectrum using the structural image
for i=1:1:number-1
    IMAG_tumorEST_final(:,:,i)=MI(:,:,i)./MI(:,:,number).*roi_brain(:,:);
end

% Define variable images to store data
mor_image_water(64,64)=0;
mor_dir_image_water(64,64)=0;

mor_image_amide(64,64)=0;
mor_dir_image_amide(64,64)=0;
mor_dir2_image_amide(64,64)=0;

mor_image_NOE3p5(64,64)=0;
mor_dir_image_NOE3p5(64,64)=0;
mor_dir2_image_NOE3p5(64,64)=0;

Zspectra_simu_water(64,64,89)=0;
Zspectra_simu_ref_water(64,64,89)=0;
Mfinf
Zspectra_simu_amide(64,64,89)=0;
Zspectra_simu_ref_amide(64,64,89)=0;

Zspectra_simu_NOE3p5(64,64,89)=0;
Zspectra_simu_ref_NOE3p5(64,64,89)=0;

IM3P(64,64)=0;
IM3PF(64,64)=0;
IM3PFe(64,64)=0;

Zspectra_mor_amide(64,64,89,1,4,rat_amount)=0;
Zspectra_mor_NOE3p5(64,64,89,1,4,rat_amount)=0;
Zspectra_dir_amide(64,64,89,1,4,rat_amount)=0;
Zspectra_dir_NOE3p5(64,64,89,1,4,rat_amount)=0;
Zspectra_dir2_amide(64,64,89,1,4,rat_amount)=0;
Zspectra_dir2_NOE3p5(64,64,89,1,4,rat_amount)=0;
image_simu_ref_amide(64,64,1,3,rat_amount)=0;
image_simu_ref_NOE3p5(64,64,1,3,rat_amount)=0;
Amide_fitted(64,64,89)  =0;
Amide_fitted_N(64,64,89) = 0;Amide_fitted_T(64,64,89) = 0;
NOE3p5_fitted(64,64,89)  =0;
NOE3p5_fitted_N(64,64,89) = 0;NOE3p5_fitted_T(64,64,89) = 0;

wc(64,64)=0;    adc(64,64)=0;
Zspectra1_simu_amide(64,64,rat_amount)=0;
IMA_tmp(64,64,89)=0;

simu_ref_amide(64,64)=0;
simu_ref_NOE3p5(64,64)=0;

IMA1(64,64,89)=0;
% %  3*3 filter Gaussian if needed
for ii=1:1:number-1
    IMA(:,:,ii)=medfilt2(IMAG_tumorEST_final(:,:,ii),[1 1]);
end

XX =64;YY=64; tempv  = 0;
for ai=1:1:XX
    for   aj=1:1:YY

        for kk=1:1:number-1
            FIMP(kk)=IMAP(ai,aj,number-kk);%number-kk
            FIM(kk)=IMA(ai,aj,number-kk);%
            FIMO(kk)=IMA(ai,aj,number-kk);%
            FIM11(kk)=IMA(ai,aj,number-kk);%
        end

        %Params use autoencoder to process FIM here.
        % % % for 1.0 uT power level
        if ai==1 && aj ==1 ; load('DCAE_CEST_Trained1p0.mat') ; end
        
         if FIM(1)==0


            IM11(ai,aj)=0;
            IM12(ai,aj)=0;
            IM13(ai,aj)=0;
            IM21(ai,aj)=0;
            IM22(ai,aj)=0;
            IM23(ai,aj)=0;
            IM31(ai,aj)=0;
            IM32(ai,aj)=0;
            IM33(ai,aj)=0;
            IM41(ai,aj)=0;
            IM42(ai,aj)=0;
            IM43(ai,aj)=0;
            IM51(ai,aj)=0;
            IM52(ai,aj)=0;
            IM53(ai,aj)=0;
            IM61(ai,aj)=0;
            IM62(ai,aj)=0;
            IM63(ai,aj)=0;

        else
            FIM_Normalized1 = rescale((FIM), 0, max(FIM));
            FIM_Normalized = repmat(FIM_Normalized1,8,1);
            FIM_op2=double(predict(net1p0_90_178,FIM_Normalized));
            FIM_op2 = mean(FIM_op2,1);
            FIM_op2_Normalized = FIM_op2;%rescale(FIM_op2, 0,max(FIM11));
            FIM_op = (FIM_op2_Normalized);

            tempv = tempv+1;
            MSE_PCA(tempv) = mse(FIMO, FIMP);
            MSE_DCAE(tempv) =mse(FIMO,FIM_op);
            MSE_ref= MSE_PCA;

            for i=1:iter

                i
                if sum(MSE_PCA)< sum(MSE_DCAE)
                    if i==1; FIM_new = FIM_op;
                    else
                        diff_FIM = FIM_op-FIM;

                        if MSE_PCA <= MSE_ref
                            FIM_new = FIM_op-1.01*diff_FIM;
                        else
                            FIM_new = FIM_op-0.99*diff_FIM;
                        end

                    end
                    options = trainingOptions('adam', 'MaxEpochs',60,...
                        'InitialLearnRate',1e-5,'Verbose',false);
                    if i==1
                        FIM_new1 = repmat(FIM_new,8,1);
                    end
               if ai<64&& aj<64
                        FIM22(1,1:89) = squeeze(IMAP(ai-1,aj-1,number-1:-1:1))';
                        FIM22(2,1:89) = squeeze(IMAP(ai-1,aj,number-1:-1:1))';
                        FIM22(3,1:89) = squeeze(IMAP(ai-1,aj+1,number-1:-1:1))';
                        FIM22(4,1:89) = squeeze(IMAP(ai,aj-1,number-1:-1:1))';
                        FIM22(5,1:89) = squeeze(IMAP(ai,aj+1,number-1:-1:1))';
                        FIM22(6,1:89) = squeeze(IMAP(ai+1,aj-1,number-1:-1:1))';
                        FIM22(7,1:89) = squeeze(IMAP(ai+1,aj,number-1:-1:1))';
                        FIM22(8,1:89) = squeeze(IMAP(ai+1,aj+1,number-1:-1:1))';
                    end

                    nL = 0;
                    for tt= 1:8;  if FIM22(9-tt,1)~=0; nL =nL +1; FIM21(nL,1:89) =FIM22(9-tt,1:89); end  ; end
                    if nL ==4||nL==5; FIM21(1,:) = mean([FIM22(1,:);FIM22(4,:)]); FIM21(2,:) = mean([FIM22(2,:);FIM22(4,:)]);FIM21(3,:) = mean([FIM22(3,:);FIM22(4,:)]);end
                    if nL ==6||nL==7; FIM21(1,:) = mean([FIM22(1,:);FIM22(4,:)]); FIM21(2,:) = mean([FIM22(2,:);FIM22(5,:)]);FIM21(3,:) = mean([FIM22(3,:);FIM22(6,:)]);end
                    if nL ==8; FIM21(1,:) = mean([FIM22(1,:);FIM22(4,:);FIM22(8,:)]); FIM21(2,:) = mean([FIM22(2,:);FIM22(6,:);FIM22(7,:)]); FIM21(3,:) = mean([FIM22(3,:);FIM22(5,:)]);end
                    FIM2 = repmat(FIMP,8,1);
                    for tt= 1:3; if FIM21(tt,1)~=0; FIM2(9-tt,:) = rescale(FIM21(tt,:), 0,max(FIMP)); end;end
                    for tt= 1:2; if FIM21(tt,1)~=0&&nL>=4; FIM2(5,:) = rescale(mean([FIM21(1,:);FIM21(2,:)]), 0,max(FIMP)); end; end

                    % figure(77); clf;
                    % plot(FIM2(1,:)); hold on; plot(FIM2(2,:));plot(FIM2(3,:),'g--');plot(FIM2(4,:),'b-.');
                    % plot(FIM2(5,:),'^'); plot(FIM2(6,:),'r--'); plot(FIM2(7,:),'m*'); plot(FIM2(8,:),'k--');

                    net1p0_90_178 = trainNetwork(FIM_new1,FIM2,net1p0_90_178.Layers,options);
                    FIM_it = rescale(FIM_new1, 0,max(FIM11));
                    FIM_op2=double(predict(net1p0_90_178,FIM_it));   %
                    FIM_op = rescale(mean(FIM_op2,1), 0,  max(FIM11));
                    MSE_PCA(tempv) = mse(FIMO, FIM2(1,:))
                end

            end
            clear FIMP
          
            sig=(1-FIM_op);
            IMA_tmp(ai,aj,1:number-1)= 1-sig;
        
            % beta0=[A, b]
            beta0= [0.9, 0/2, 560/2,               0.025, -1400/2, 200/2,        0.01, -800/2, 600/2,        0.001, 600/2, 400/2,          0.02, 1400/2, 1200/2,          0.1, 0/2, 10000/2]; % initial test
            lb=[0.02, -400/2, 120/2,               0, -1600/2, 160/2,             0, -1200/2, 200/2,           0, 400/2, 0/2,                0, 1000/2, 400/2,            0, -1600/2, 4000/2]; % lower bound
            ub=[1, 400/2,4000/2,                    0.2, -1200/2, 1200/2,          0.2,-400/2, 2000/2,         0.2, 800/2, 600/2,            1, 1800/2, 2000/2,         1, 1600/2, 40000/2]; % upper bound

            % Delta =[sep; R1S; R1W; R1M; R2M; mnotw];

            Delta=[1]; % constants

            options=optimset('lsqcurvefit') ;
            options = optimset('Display','off','TolFun',1e-8,'TolX',1e-8,'MaxFunEvals',5e4*length(x),'MaxIter',2e5) ;

            [beta,resnorm,residual,exitflag,output,lambda,jacobian] = ...
                lsqcurvefit(@matsolv, beta0, x, sig, lb, ub, options, Delta) ;

            sig_simu=matsolv(beta,x,Delta);


            IM11(ai,aj)=beta(1);
            IM12(ai,aj)=beta(2);
            IM13(ai,aj)=beta(3);
            IM21(ai,aj)=beta(4);
            IM22(ai,aj)=beta(5);
            IM23(ai,aj)=beta(6);
            IM31(ai,aj)=beta(7);
            IM32(ai,aj)=beta(8);
            IM33(ai,aj)=beta(9);
            IM41(ai,aj)=beta(10);
            IM42(ai,aj)=beta(11);
            IM43(ai,aj)=beta(12);
            IM51(ai,aj)=beta(13);
            IM52(ai,aj)=beta(14);
            IM53(ai,aj)=beta(15);
            IM61(ai,aj)=beta(16);
            IM62(ai,aj)=beta(17);
            IM63(ai,aj)=beta(18);

            % water
            beta_water=beta;
            sig_simur_water=matsolv(beta_water,x,Delta);
            beta_water(4)=0;
            beta_water(7)=0;
            beta_water(10)=0;
            beta_water(13)=0;
            beta_water(16)=0;
            sig_simur_ref_water=matsolv(beta_water,x,Delta);

              for nn=1:1:number-1
                Zspectra_simu_water(ai,aj,nn)=sig_simur_water(nn);
                Zspectra_simu_ref_water(ai,aj,nn)=sig_simur_ref_water(nn);
                Zspectra_mor_water(ai,aj,nn,rat_time,rat_power, rat_number)=sig_simur_ref_water(nn);
            end

            % amide

            beta_amide=beta;
            sig_simur_amide=matsolv(beta_amide,x,Delta);
            beta_amide(4)=0;
            sig_simur_ref_amide=matsolv(beta_amide,x,Delta);

            mor_amide=(1./(1-sig_simur_amide)-1./(1-sig_simur_ref_amide));
            mor_dir_amide=(sig_simur_amide-sig_simur_ref_amide);
            mor_dir2_amide=((1-sig_simur_ref_amide)-(1-sig_simur_amide))./(1-sig_simur_ref_amide);

            for nn=1:1:number-1
                Zspectra_simu_amide(ai,aj,nn)=sig_simur_amide(nn);
                Zspectra1_simu_amide(ai,aj,nn)=1-sig_simur_amide(nn);
                Zspectra_simu_ref_amide(ai,aj,nn)=sig_simur_ref_amide(nn);
                Zspectra_mor_amide(ai,aj,nn,rat_time,rat_power, rat_number)=mor_amide(nn);
                Zspectra_dir_amide(ai,aj,nn,rat_time,rat_power, rat_number)=mor_dir_amide(nn);
                Zspectra_dir2_amide(ai,aj,nn,rat_time,rat_power, rat_number)=mor_dir2_amide(nn);
            end

            mor_image_amide(ai,aj)=max(mor_amide(15:19)); % 
            mor_dir_image_amide(ai,aj)=max(mor_dir_amide(15:19));
            mor_dir2_image_amide(ai,aj)=max(mor_dir2_amide(15:19));

            simu_ref_amide(ai,aj)=sig_simur_ref_amide(17);

            Amide_fitted(ai,aj,:) = mor_amide(1:89)*roi_brain(ai,aj);
            Amide_fitted(ai,aj,17) = mor_image_amide(ai,aj)*roi_brain(ai,aj);

            Amide_fitted_N(ai,aj,:) = mor_amide(1:89)*roi_brain_normal1(ai,aj);
            Amide_fitted_N(ai,aj,17) = mor_image_amide(ai,aj)*roi_brain_normal1(ai,aj);
            Amide_fitted_T(ai,aj,:) = mor_amide(1:89)*roi_brain_tumor(ai,aj);
            Amide_fitted_T(ai,aj,17) = mor_image_amide(ai,aj)*roi_brain_tumor(ai,aj);

           
            % NOE3p5
            beta_NOE3p5=beta;
            sig_simur_NOE3p5=matsolv(beta_NOE3p5,x,Delta);
            beta_NOE3p5(13)=0;
            
            sig_simur_ref_NOE3p5=matsolv(beta_NOE3p5,x,Delta);

            mor_NOE3p5=(1./(1-sig_simur_NOE3p5)-1./(1-sig_simur_ref_NOE3p5));
            mor_dir_NOE3p5=(sig_simur_NOE3p5-sig_simur_ref_NOE3p5);
            mor_dir2_NOE3p5=((1-sig_simur_ref_NOE3p5)-(1-sig_simur_NOE3p5))./(1-sig_simur_ref_NOE3p5);

            for nn=1:1:number-1
                Zspectra_simu_NOE3p5(ai,aj,nn)=sig_simur_NOE3p5(nn);
                Zspectra_simu_ref_NOE3p5(ai,aj,nn)=sig_simur_ref_NOE3p5(nn);
                Zspectra_mor_NOE3p5(ai,aj,nn,rat_time,rat_power, rat_number)=mor_NOE3p5(nn);
                Zspectra_dir_NOE3p5(ai,aj,nn,rat_time,rat_power, rat_number)=mor_dir_NOE3p5(nn);
                Zspectra_dir2_NOE3p5(ai,aj,nn,rat_time,rat_power, rat_number)=mor_dir2_NOE3p5(nn);
            end

            mor_image_NOE3p5(ai,aj)=max(mor_NOE3p5(69:77));
            mor_dir_image_NOE3p5(ai,aj)=max(mor_dir_NOE3p5(69:77));
            mor_dir2_image_NOE3p5(ai,aj)=max(mor_dir2_NOE3p5(69:77));

            simu_ref_NOE3p5(ai,aj)=sig_simur_ref_NOE3p5(72);
            NOE3p5_fitted(ai,aj,:) = mor_NOE3p5(1:89)*roi_brain(ai,aj);
            NOE3p5_fitted(ai,aj,73) = mor_image_NOE3p5(ai,aj)*roi_brain(ai,aj);

            NOE3p5_fitted_N(ai,aj,:) = mor_NOE3p5(1:89)*roi_brain_normal1(ai,aj);
            NOE3p5_fitted_N(ai,aj,73) = mor_image_NOE3p5(ai,aj)*roi_brain_normal1(ai,aj);
            NOE3p5_fitted_T(ai,aj,:) = mor_NOE3p5(1:89)*roi_brain_tumor(ai,aj);
            NOE3p5_fitted_T(ai,aj,73) = mor_image_NOE3p5(ai,aj)*roi_brain_tumor(ai,aj);

        end
    end
    ai
end
%%
IMAOrig = IMA;  IMA = IMA_tmp;
% amide signal in tumor and normal tissue
for k=1:1:89
    Zspectra_tumor(k, rat_time, rat_power, rat_number)=sum(sum(IMA(:,:,k).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_normal(k, rat_time, rat_power, rat_number)=sum(sum(IMA(:,:,k).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra(k, rat_time, rat_power, rat_number)=sum(sum(IMA(:,:,k).*roi_brain))./sum(sum(roi_brain));
    Zspectra_residual_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra1_simu_amide(:,:,k).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_residual_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra1_simu_amide(:,:,k).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    IMA_tempN = IMA(:,:,k).*roi_brain_normal1; IMA_tempN(IMA_tempN==0)=nan;
    IMA_tempT = IMA(:,:,k).*roi_brain_tumor; IMA_tempT(IMA_tempT==0)=nan;

    Zspectra_tumor_std(k, rat_time, rat_power, rat_number)=std(std(IMA_tempT,'omitnan'),'omitnan');
    Zspectra_normal_std(k, rat_time, rat_power, rat_number)=std(std(IMA_tempN,'omitnan'),'omitnan');
end

for k=1:1:89
    Zspectra_mor_amide_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_amide(:,:,k, rat_time,rat_power,  rat_number).*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_mor_amide_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_amide(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_mor_amide_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_amide(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));
    Zspectra_mor_amideN = Zspectra_mor_amide(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_normal1; Zspectra_mor_amideN(Zspectra_mor_amideN==0)=nan;
    Zspectra_mor_amideT = Zspectra_mor_amide(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor; Zspectra_mor_amideT(Zspectra_mor_amideT==0)=nan;

    AptFZspectra_tumor_std(k)=1.2*std(std(Zspectra_mor_amideT,'omitnan'),'omitnan');
    AptFZspectra_normal_std(k)=1.2*std(std(Zspectra_mor_amideN,'omitnan'),'omitnan');

end

%%
for k=1:1:89
    Zspectra_mor_NOE3p5_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_mor_NOE3p5_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_mor_NOE3p5_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));

    Zspectra_mor_NOE3p5N = Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1;
    Zspectra_mor_NOE3p5N(Zspectra_mor_NOE3p5N==0)=nan;
    Zspectra_mor_NOE3p5T = Zspectra_mor_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain_tumor;
    Zspectra_mor_NOE3p5T(Zspectra_mor_NOE3p5T==0)=nan;

    NOEFZspectra_tumor_std(k)=1.2*std(std(Zspectra_mor_NOE3p5T,'omitnan'),'omitnan');
    NOEFZspectra_normal_std(k)=1.2*std(std(Zspectra_mor_NOE3p5N,'omitnan'),'omitnan');

end
%%
for k=1:1:89
    Zspectra_simu_ref_amide_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_amide(:,:,k).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_simu_ref_amide_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_amide(:,:,k).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_simu_ref_amide_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_amide(:,:,k).*roi_brain))./sum(sum(roi_brain));
end

for k=1:1:89
    Zspectra_simu_ref_NOE3p5_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_NOE3p5(:,:,k).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_simu_ref_NOE3p5_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_NOE3p5(:,:,k).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_simu_ref_NOE3p5_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_simu_ref_NOE3p5(:,:,k).*roi_brain))./sum(sum(roi_brain));
end

for k=1:1:89
    Zspectra_dir_amide_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_amide(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_dir_amide_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_amide(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_dir_amide_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_amide(:,:,k, rat_time, rat_power, rat_number).*roi_brain))./sum(sum(roi_brain));
end

for k=1:1:89
    Zspectra_dir_NOE3p5_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_NOE3p5(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_dir_NOE3p5_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_dir_NOE3p5_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain))./sum(sum(roi_brain));
end


for k=1:1:89
    Zspectra_dir2_amide_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_amide(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_dir2_amide_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_amide(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_dir2_amide_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_amide(:,:,k, rat_time, rat_power, rat_number).*roi_brain))./sum(sum(roi_brain));
end

for k=1:1:89
    Zspectra_dir2_NOE3p5_tumor(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_NOE3p5(:,:,k, rat_time,rat_power,  rat_number).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
    Zspectra_dir2_NOE3p5_normal(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
    Zspectra_dir2_NOE3p5_all(k, rat_time, rat_power, rat_number)=sum(sum(Zspectra_dir2_NOE3p5(:,:,k, rat_time, rat_power, rat_number).*roi_brain))./sum(sum(roi_brain));
end


AREX_image_dir_amide(:,:, rat_time, rat_power, rat_number) =mor_dir_image_amide.*roi_brain;
AREX_image_dir_NOE3p5(:,:, rat_time, rat_power, rat_number) =mor_dir_image_NOE3p5.*roi_brain;

AREX_image_mor_amide(:,:, rat_time, rat_power, rat_number) =mor_image_amide.*R1fmap.*(1+0).*roi_brain;
AREX_image_mor_NOE3p5(:,:, rat_time, rat_power, rat_number) =mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain;

AREX_image_mor_amide_watercontent(:,:, rat_time, rat_power, rat_number) =mor_image_amide.*R1fmap.*(1+0).*roi_brain.*Mfinf;
AREX_image_mor_NOE3p5_watercontent(:,:, rat_time, rat_power, rat_number) =mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain.*Mfinf;

AREX_image_mor_noR1correction_amide(:,:, rat_time, rat_power, rat_number) =mor_image_amide.*roi_brain;
AREX_image_mor_noR1correction_NOE3p5(:,:, rat_time, rat_power, rat_number) =mor_image_NOE3p5.*roi_brain;

Value_AREX_image_mor_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_AREX_image_mor_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));

Value_AREX_image_mor_amide(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));
Value_AREX_image_mor_NOE3p5(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));

Value_AREX_image_mor_amide_tumor_watercontent(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*Mfinf.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_AREX_image_mor_NOE3p5_tumor_watercontent(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*Mfinf.*roi_brain_tumor))./sum(sum(roi_brain_tumor));

Value_AREX_image_mor_noR1correction_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_AREX_image_mor_noR1correction_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*roi_brain_tumor))./sum(sum(roi_brain_tumor));

Value_AREX_image_mor_amide_normal_watercontent(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*Mfinf.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_AREX_image_mor_NOE3p5_normal_watercontent(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*Mfinf.*roi_brain_normal1))./sum(sum(roi_brain_normal1));


Value_AREX_image_mor_amide_normal(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_AREX_image_mor_NOE3p5_normal(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain_normal1))./sum(sum(roi_brain_normal1));

Value_AREX_image_mor_noR1correction_amide_normal(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_AREX_image_mor_noR1correction_NOE3p5_normal(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*roi_brain_normal1))./sum(sum(roi_brain_normal1));

Value_AREX_image_mor_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_AREX_image_mor_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain_tumor))./sum(sum(roi_brain_tumor));

Value_AREX_image_mor_amide(rat_time, rat_power, rat_number)=sum(sum(mor_image_amide.*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));
Value_AREX_image_mor_NOE3p5(rat_time, rat_power, rat_number)=sum(sum(mor_image_NOE3p5.*R1fmap.*(1+0).*roi_brain))./sum(sum(roi_brain));

MTR_image_dir2_amide(:,:, rat_time, rat_power, rat_number) =mor_dir2_image_amide.*roi_brain;
MTR_image_dir2_NOE3p5(:,:, rat_time, rat_power, rat_number) =mor_dir2_image_NOE3p5.*roi_brain;

Value_MTR_image_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_amide.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_MTR_image_amide_normal(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_amide.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_MTR_image_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_NOE3p5.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_MTR_image_NOE3p5_normal(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_NOE3p5.*roi_brain_normal1))./sum(sum(roi_brain_normal1));


Value_MTR_image_amide(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_amide.*roi_brain))./sum(sum(roi_brain));
Value_MTR_image_NOE3p5(rat_time, rat_power, rat_number)=sum(sum(mor_dir_image_NOE3p5.*roi_brain))./sum(sum(roi_brain));
Value_MTR2_image_amide(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_amide.*roi_brain))./sum(sum(roi_brain));
Value_MTR2_image_NOE3p5(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_NOE3p5.*roi_brain))./sum(sum(roi_brain));

Value_MTR2_image_amide_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_amide.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_MTR2_image_amide_normal(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_amide.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
Value_MTR2_image_NOE3p5_tumor(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_NOE3p5.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
Value_MTR2_image_NOE3p5_normal(rat_time, rat_power, rat_number)=sum(sum(mor_dir2_image_NOE3p5.*roi_brain_normal1))./sum(sum(roi_brain_normal1));

value_R1fmap_tumor(rat_number)=sum(sum(R1fmap.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
value_R1fmap_normal(rat_number)=sum(sum(R1fmap.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
value_R1fmap(rat_number)=sum(sum(R1fmap.*roi_brain))./sum(sum(roi_brain));
value_pmfmap_tumor(rat_number)=sum(sum(pmfmap.*roi_brain_tumor))./sum(sum(roi_brain_tumor));

value_pmfmap_normal(rat_number)=sum(sum(pmfmap.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
value_pmfmap(rat_number)=sum(sum(pmfmap.*roi_brain))./sum(sum(roi_brain));
value_kmfmap_tumor(rat_number)=sum(sum(kmfmap.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
value_kmfmap_normal(rat_number)=sum(sum(kmfmap.*roi_brain_normal1))./sum(sum(roi_brain_normal1));

value_kmfmap(rat_number)=sum(sum(kmfmap.*roi_brain))./sum(sum(roi_brain));
value_Mfinf_tumor(rat_number)=sum(sum(Mfinf.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
value_Mfinf_n_brormal(rat_number)=sum(sum(Mfinf.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
value_Mfinf(rat_number)=sum(sum(Mfinf.*roi_brain))./sum(sum(roi_brain));

image_simu_ref_amide(:,:, rat_time, rat_power, rat_number)=simu_ref_amide;
image_simu_ref_NOE3p5(:,:, rat_time, rat_power, rat_number)=simu_ref_NOE3p5;

value_R1Wmap_tumor(rat_number)=sum(sum(R1W_map.*roi_brain_tumor))./sum(sum(roi_brain_tumor));
value_R1Wmap_normal(rat_number)=sum(sum(R1W_map.*roi_brain_normal1))./sum(sum(roi_brain_normal1));
value_R1Wmap(rat_number)=sum(sum(R1W_map.*roi_brain))./sum(sum(roi_brain));
toc

%%
Amide_fitted_DCAE     = Zspectra_mor_amide_all(:,1,rat_power);
NOE3p5_fitted_DCAE = Zspectra_mor_NOE3p5_all(:,1,rat_power);
else

%%
PCA_max = max(max(A_PCA));
A= 100*(mor_image_amide.*roi_brain).*R1fmap;%
% A = 100*AREX_image_mor_amide(:,:,1,2);
DCAE_max = max(max(A));
A1= A;
A1(A1==0)=nan;
A_mean= mean(mean(A1,'omitnan'),'omitnan');  A_std = std(std(A,'omitnan'),'omitnan');
AMD_DCAE =(A- A_mean+ AMD_mean_PCA);
A1 = imcrop(A,[16 17 28 19]); 
AMD_DCAE1 = imcrop(AMD_DCAE,[16 17 28 19]);
ax=figure; imagesc(PCA_max.*A1./DCAE_max); axis off; c=colorbar('FontSize',18);
ax=figure; imagesc(PCA_max.*AMD_DCAE1./DCAE_max); axis off; c=colorbar('FontSize',18); caxis([0, 10]);
c=colorbar('FontSize',18);axis off;
w = c.LineWidth;  c.LineWidth = 1.5;
%%
% exportgraphics(ax,[pwd '/outputs/Amiderat11p0_DCAECEST6.png'],'Resolution',300)

%

ATum = A.*roi_brain_tumor;
ANor = A.*roi_brain_normal1;
AROINT= ANor+ATum;
rat1_Amide1p0T= ATum; rat1_Amide1p0N= ANor;
ATum(ATum==0)=nan;ANor(ANor==0)=nan;
mean_Tum = mean(mean(ATum,'omitnan'),'omitnan')
std_Tum = std(std(ATum,'omitnan'),'omitnan')
mean_Nor = mean(mean(ANor,'omitnan'),'omitnan')
std_Nor = std(std(ANor,'omitnan'),'omitnan')




%%
PCA_max = max(max(A_PCA));
% A= 100*(mor_image_amide.*roi_brain).*R1fmap;%
A = 100*AREX_image_mor_amide(:,:,1,2);
DCAE_max = max(max(A));
A1= A;
A1(A1==0)=nan;
A_mean= mean(mean(A1,'omitnan'),'omitnan');  A_std = std(std(A,'omitnan'),'omitnan');
AMD_DCAE =(A- A_mean+ AMD_mean_PCA);
A1 = imcrop(A,[16 17 28 19]); 
AMD_DCAE1 = imcrop(AMD_DCAE,[16 17 28 19]);
ax=figure; imagesc(A1); axis off; c=colorbar('FontSize',18); caxis([0, 10]);
% ax=figure; imagesc(PCA_max.*A1./DCAE_max); axis off; c=colorbar('FontSize',18); caxis([0, 10]);
% ax=figure; imagesc(PCA_max.*AMD_DCAE1./DCAE_max); axis off; c=colorbar('FontSize',18);caxis([0, 10]);
c=colorbar('FontSize',18);axis off;
w = c.LineWidth;  c.LineWidth = 1.5;
%cl
% cccc
% exportgraphics(ax,[pwd '/Figs/rat3/P1p0/Amiderat31p0_DCAECEST231WOCL.png'],'Resolution',300)

%%

ATum = A.*roi_brain_tumor;
ANor = A.*roi_brain_normal1;
AROINT= ANor+ATum;
rat3_Amide1p0T= ATum; rat3_Amide1p0N= ANor;
ATum(ATum==0)=nan;ANor(ANor==0)=nan;
mean_Tum = mean(mean(ATum,'omitnan'),'omitnan')
std_Tum = std(std(ATum,'omitnan'),'omitnan')
mean_Nor = mean(mean(ANor,'omitnan'),'omitnan')
std_Nor = std(std(ANor,'omitnan'),'omitnan')


% B =100*(mor_image_NOE3p5.*roi_brain).*(R1fmap);
B = 100*AREX_image_mor_NOE3p5(:,:,1,2);
B1= imcrop(B,[16 17 28 19]); 
ax=figure;imagesc(B1);axis off;colorbar; caxis([0, 25]);
c=colorbar('FontSize',18);axis off;
w = c.LineWidth;
c.LineWidth = 1.5;
% cccc
% % % exportgraphics(ax,[pwd '/Figs/rat3/P1p0/NOE3p5Maprat31p0_DCAECEST231WOCL.png'],'Resolution',300)
%%
APTqua_DCAECEST =Brisque(A1)
NOEQua_DCAECEST =Brisque(B1) 

NOETum =B.*roi_brain_tumor;
NOENor = B.*roi_brain_normal1;
rat3_NOE1P0T= NOETum; rat3_NOE1P0N= NOENor;
ROINT= NOENor+NOETum;
NOETum(NOETum==0)=nan;NOENor(NOENor==0)=nan;
mean_TumNOE= mean(mean(NOETum.*roi_brain_tumor,'omitnan'),'omitnan')
std_TumNOE= std(std(NOETum.*roi_brain_tumor,'omitnan'),'omitnan')
mean_NorNOE= mean(mean(NOENor.*roi_brain_normal1,'omitnan'),'omitnan')
std_NorNOE= std(std(NOENor.*roi_brain_normal1,'omitnan'),'omitnan')

%% 

str = 'rat3';
APT_DCAECEST30=  sscanf(str,'rat%d')
T2 = table(APT_DCAECEST30, 1*mean_Nor, 1*std_Nor,1*mean_Tum, 1*std_Tum, 1*mean_NorNOE, 1*std_NorNOE,1*mean_TumNOE, 1*std_TumNOE)
% writetable(T2,'Invivo_New1p0.xlsx','Sheet','DCAECEST','WriteMode','append')

%%



% B =100*(mor_image_NOE3p5.*roi_brain).*(R1fmap);
B = 100*AREX_image_mor_NOE3p5(:,:,1,2);
B1= imcrop(B,[16 17 28 19]); 
ax=figure;imagesc(B1);axis off;colorbar; caxis([0, 25]);
c=colorbar('FontSize',18);axis off;
w = c.LineWidth;
c.LineWidth = 1.5;
%
% exportgraphics(ax,[pwd '/outputs/NOE3p5Maprat11p0_DCAECEST6.png'],'Resolution',300)

NOETum =B.*roi_brain_tumor;
NOENor = B.*roi_brain_normal1;
rat1_NOE1P0T= NOETum; rat1_NOE1P0N= NOENor;
ROINT= NOENor+NOETum;
NOETum(NOETum==0)=nan;NOENor(NOENor==0)=nan;
mean_TumNOE= mean(mean(NOETum.*roi_brain_tumor,'omitnan'),'omitnan')
std_TumNOE= std(std(NOETum.*roi_brain_tumor,'omitnan'),'omitnan')
mean_NorNOE= mean(mean(NOENor.*roi_brain_normal1,'omitnan'),'omitnan')
std_NorNOE= std(std(NOENor.*roi_brain_normal1,'omitnan'),'omitnan')

%% 

str = 'rat1';
APT_DCAECEST=  sscanf(str,'rat%d')
T2 = table(APT_DCAECEST, 1*mean_Nor, 1*std_Nor,1*mean_Tum, 1*std_Tum, 1*mean_NorNOE, 1*std_NorNOE,1*mean_TumNOE, 1*std_TumNOE)
% writetable(T2,'Invivo_New1p0.xlsx','Sheet','DCAECEST','WriteMode','append')
end
%%


