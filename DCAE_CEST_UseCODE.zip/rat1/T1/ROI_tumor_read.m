clear
load('roi_brain')
for ii=1:1:64
    for jj=1:1:64
        
        if pmfmap(ii,jj)<0.04
            roi_auto_brain_tumor(ii,jj)=1;
        else
            roi_auto_brain_tumor(ii,jj)=0;
        end
    end
end
figure (1)
imagesc(roi_auto_brain_tumor)
roi_draw_brain_tumor=roipoly
roi_brain_tumor=roi_draw_brain_tumor.*roi_auto_brain_tumor;

figure (2)
imagesc(pmfmap)
roi_brain_normal=roipoly
