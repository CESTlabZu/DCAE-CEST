function ParMaps = MRI_fit_sirqMT(IMAG, time_pars, ROI, fit_pars)
%% MRI_fit_SIR_qMT fits qMT data based on selective inversion recovery method
% Li et al. Magn Reson Med. 2010 Aug;64(2):491-500.
% Inputs: 
%       imset:      imaging data
%       time_pars:  [ti, td], sec
%       ROI:        ROI for fitting
%       fit_pars:   all imaging parameters for fitting
% Outputs:
%       ParMaps:    3D fitted parametric map
% ------------------------------------------
% originally written by Ke Li
% ------------------------------------------
% modified by jzxu, 2012_02_07
% ------------------------------------------
%


if (nargin==3)
    sig_threshold = 0 ; 
%     Delta_fit = [ 0.83 ; 1 ]; % simulated constants
    beta=[0.4 0.1 30 -0.95 0.1];
    lb=[ 0.1  0.01  1  -1.1   1e-5 ];
    ub=[ 4.5 0.9  500  -0.2   1e7];
elseif (nargin==4)
    sig_threshold = fit_pars.sig_threshold ; 
%     Delta_fit = fit_pars.Delta_fit ; 
    beta = fit_pars.beta ; 
    lb = fit_pars.lb ; 
    ub = fit_pars.ub ; 
end


    [Nx, Ny] = size(IMAG(:,:,1));
    ParMaps = zeros(Nx, Ny, 5);

    
    disp('start SIR_qMT data fitting...');
    [X, Y] = find(ROI>0) ; 
    for nvox = 1:length(X)
        % signals
        signal = squeeze(IMAG(X(nvox), Y(nvox), :)) ; 
        
        % set signal threshold
        if abs(signal(1)) < sig_threshold
            continue;
        end
        
        % fit
        [sircoeff,resnorm,ci] = sir_fit(fit_pars, time_pars, signal, beta, lb, ub) ;

        str = sprintf('pixel:%d,%d: R1f=%.3f,pmf=%.3f,kmf=%.3f,Sf=%.3f,Mfinf=%.3f', ...
                X(nvox), Y(nvox),sircoeff(1),sircoeff(2),sircoeff(3),sircoeff(4),sircoeff(5));
        disp(str);

        for npar=1:5
            ParMaps(X(nvox), Y(nvox), npar) = sircoeff (npar);
        end
        
    end

    disp('sirqMT fitting ... done!');
end


%% fit signal vs ti curve according SIR qMT model
function [beta,resnorm,ci] = sir_fit(fit_pars, time_pars, signal, beta0, lb, ub)

options = optimset('Display','off','TolFun',1e-8,'TolX',1e-8,'MaxFunEvals',5e4*length(time_pars),'MaxIter',2e5) ; 

[beta,resnorm,residual,exitflag,output,lambda,jacobian] = ...
    lsqcurvefit(@Physics_get_sirqMT_signal, beta0, time_pars, signal, lb, ub, options, fit_pars) ; 

% ci = nlparci(beta,residual,'jacobian',jacobian);
% ci = nlparci(beta,residual,'jacobian',jacobian,'alpha',0.95);
ci =1;
end



