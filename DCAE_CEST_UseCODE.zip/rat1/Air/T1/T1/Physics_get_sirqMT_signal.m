function signal  = Physics_get_sirqMT_signal(par, x, fit_pars)
%% signal of SIR_qMT
% Inputs
%       par: a vector of parameters: [R1f, pmf, kmf, Sf, Mfinf]
%       x: [ti td]
%       Delta: constant [Sm R1m]
%           NOTE: time unit is second !
% Outputs
%       sig: theoretical signal of sir_qMT based on input par 
%
% -----------------------------------------------------------
% written by Ke Li
% -----------------------------------------------------------
% revised by jzxu, 2012_02_08
% -----------------------------------------------------------

    % assign parameters
    R1f  = par(1);
    pmf  = par(2);
    kmf  = par(3);
    Sf   = par(4);
    Mfinf= par(5);  
    
    Sm = fit_pars.Sm ; 
    R1m = fit_pars.R1m ; 
     
    ti = x( :, 1);
    td = x( :, 2);

    R1diff  = sqrt( (R1f-R1m+(pmf-1) .* kmf) .^ 2 + 4 * pmf .* kmf .* kmf );
    
    R1plus  = 0.5 .* (R1f + R1m + (1+pmf).*kmf + R1diff);

    R1minus = R1plus-R1diff;

    bftdplus = -(R1f - R1minus) ./ R1diff;
    bftdminus = (R1f - R1plus) ./ R1diff;

    bmtdplus  = -(R1m - R1minus) ./ R1diff;
    bmtdminus = (R1m - R1plus) ./ R1diff;


    Mftd = bftdplus .* exp(-R1plus .* td) + bftdminus .* exp(-R1minus .* td) + 1 ; 
    Mmtd = bmtdplus .* exp(-R1plus .* td) + bmtdminus .* exp(-R1minus .* td) + 1 ; 

    bfplus = ( (Sf .* Mftd -1) .* (R1f - R1minus)  +  ...
        (Sf .* Mftd - Sm .* Mmtd) .* pmf .* kmf  ) ./ R1diff;
    bfminus = -( (Sf .* Mftd -1).* (R1f - R1plus)  + ...
        (Sf .* Mftd - Sm .* Mmtd) .* pmf .* kmf  ) ./ R1diff;

    signal = (bfplus .* exp ( - R1plus .* ti) + bfminus .* exp ( -R1minus .*ti) +1) .* Mfinf  ;
    
    % get amplitude of signal only
    if strcmp(fit_pars.type,'abs')
        signal = abs(signal) ; 
    end

end

