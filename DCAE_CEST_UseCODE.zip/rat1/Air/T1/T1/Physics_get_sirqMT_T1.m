function T1  = Physics_get_sirqMT_T1(par, fit_pars)
%% calculate apparent T1 using SIR_qMT model 
% Inputs
%       par: a vector of parameters: [R1f, pmf, kmf, Sf, Mfinf]
%           Note: the time unit is in second
% Outputs
%       T1: apparent T1, ms
%
% written by jzxu, 2012_03_06
% -----------------------------------------------------------

if numel(par) == 5
    par = reshape(par,[1 1 5]) ; 
end


    % assign parameters
    R1f  = par(:,:,1);
    pmf  = par(:,:,2);
    kmf  = par(:,:,3);
    Sf   = par(:,:,4);
    Mfinf= par(:,:,5);  
    
    Sm = fit_pars.Sm ; 
    R1m = fit_pars.R1m ; 
    
    R1diff  = sqrt( (R1f-R1m+(pmf-1) .* kmf) .^ 2 + 4 * pmf .* kmf .* kmf );
    
    R1plus  = 0.5 .* (R1f + R1m + (1+pmf).*kmf + R1diff);

    R1minus = R1plus - R1diff ; 
    
    T1 = 1000 ./ R1minus ; % ms


end

