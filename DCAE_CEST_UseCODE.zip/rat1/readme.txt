G:\back up\F\work\experiments\2018.2.19_4p7T_tumor_rat
all take with air, except where noticed
CEST

0.25uT  0.5uT   1uT 2uT 3uT  4uT



TR 15000
 ESP 12

 ETL 8
 kzero 4
 Effective TE 48
 average 1

 Ti  0.01   0.0275  0.0758  0.209  0.575  1.58  4.4  12
