%function DCAE_CEST 

% Denoising Convolution AutoEncoder Model Design and its training loops
%%
load('CEST_DataB1Variation2.mat') % Clean_sample= N
% total samples = 6N %% for N clean data and 5N noisy data samples
N = 14;  %let 
%% CC = CEST_DataAEDenoising(:,90:267); The offsets are 89 for each Z-spectrum
Y= Cest_Data(1:N,179:267);

Y_data =  [Y;Y;Y;Y;Y]; % Five time repetition of clean data as reference for 5 types of noisy data 

CC = [Cest_Data(N+1:end,179:267)];
%CC1 = Cest_Data(1:N,179:267);
data = [CC];%CC1];

% Cross varidation (train: 70%, test: 30%)
cv = cvpartition(size(data,1),'HoldOut',0.3);
idx = cv.test;
% Separate to training and test data
XTrain = data(~idx,:);
YTrain = Y_data(~idx,:);
XValidation  = data(idx,:);
YValidation = Y_data(idx,:);


XTest =XValidation ;
Ytest =YValidation;
%%
X2 = XTrain;Y2 = YTrain; % temporary variables for randomization of data
[m,n] = size(XTrain);
idx = randperm(m);
for ii= 1:m
XTrain(ii,:)= X2(idx(ii),:);
YTrain(ii,:)= Y2(idx(ii),:);
end
clear X2 Y2




%%
numFeatures = 8;
%numClasses = 10;
minLength = 89;
filterSize = 3;
numFilters = 128;
%% Define the DCAE Network Layers as Encoder and Decoder 

layers = [ % Encoder Network
    sequenceInputLayer(numFeatures,MinLength=minLength)  % Input Layer
    convolution1dLayer(filterSize,numFilters/4,Padding='same');
    eluLayer   % Activation Layer 
    maxPooling1dLayer(2,'Stride',2,Padding='same');
    convolution1dLayer(filterSize,numFilters/2,Padding='same');
    eluLayer
    maxPooling1dLayer(2,'Stride',2,Padding='same');
    convolution1dLayer(filterSize,numFilters,Padding='same');
    eluLayer
    maxPooling1dLayer(2,'Stride',2,Padding='same');
   
    
    flattenLayer('Name','flatten');
    fullyConnectedLayer(32);  % BottleNeck Layer 

    % Decoder Network
 
    transposedConv1dLayer(filterSize,numFilters,Stride=2,Cropping=[1 1])
    convolution1dLayer(filterSize,numFilters,Padding='same');
    transposedConv1dLayer(filterSize,numFilters/2,Stride=2,Cropping=[1 1])
    convolution1dLayer(filterSize,numFilters/2,Padding='same');
    transposedConv1dLayer(filterSize,numFilters/4,Stride=2,Cropping=[1 1])
    convolution1dLayer(filterSize,numFeatures,Padding='same');
    regressionLayer]; % 

%% Set the Optimization parameters for the training and loss Optimization of the DCAE Model
    options = trainingOptions('adam', 'MaxEpochs',200,'MiniBatchSize',8,...
    'InitialLearnRate',1e-4,'Verbose',true,'ValidationData',{XValidation,YValidation}); % ,'Plots','training-progress'

    %% Visuialize and see the details of DCAE Network
lgraph = layerGraph(layers);
analyzeNetwork(layers)

%% Select the data for training  
% For fine tuning 0.5 uT  OR 1uT power level OR Mixed Data with Both Power levels for Pretraining 

%%  for the retraining the saved model
 % load('net1p0_90_178_SingleStage.mat')
 % layers = net1p0_90_178_SingleStage.Layers;

 %% Training network

   LossTrain(6*N) = 0;
   LossValidation(6*N) = 0;
   mse_pred_AE((6*N)) = 0;
   kk=1;
for i=1:7:42
    if i>=size(YTrain,1)-7 ;  break;  end % Condition to break loop at extreme data point

    XTrain1 = XTrain(i:i+7,1:89); % Training for a batch size of 8 Samples
    XTrain11= awgn(XTrain1,35,'measured'); % Add Gaussian Noise
    XTrain2 = YTrain(i:i+7,1:89);

%  Update Validation data when it is large size data
% if i<=size(Ytest,1)
%   options = trainingOptions('adam', 'MaxEpochs',200,'MiniBatchSize',8,...
%     'InitialLearnRate',1e-4,'Verbose',true,'ValidationData',{XValidation(i:i+7,:),YValidation(i:i+7,:)}); % ,'Plots','training-progress'
% end
% if i>size(Ytest,1)
%     j = size(Ytest,1)-8;
%   options = trainingOptions('adam', 'MaxEpochs',200,'MiniBatchSize',8,...
%     'InitialLearnRate',1e-4,'Verbose',true,'ValidationData',{XValidation(j:j+7,:),YValidation(j:j+7,:)}); % ,'Plots','training-progress'
% end
   [net1p0,info]  = trainNetwork(XTrain11,XTrain2,layers,options);i
   kk= kk+2;
   LossTrain(kk-1:kk) = [info.TrainingLoss(150) info.TrainingLoss(160)];
   LossValidation(kk-1:kk) = [info.TrainingLoss(150);info.TrainingLoss(160)];

    if mod(i,5)== 0 % 
        %figure(31);clf;
        for j= 1:8%:20
            xtest(j:j+7,:)=awgn(XTest(j:j+7,:),35,'measured');
            xReconstructed(j:j+7,:) = predict(net1p,xtest(j:j+7,:));
%              plot(xtest(j,1:89),'r'); hold on; plot(xReconstructed(j,:),'b');
%              plot((xtest(j,1:89)-xReconstructed(j,:)),'r.-');

 KL_divv(i) = KLDiv2(xReconstructed(i,:), XTest(i,1:89));
        end
        mse_pred= mse(XTest(1,:),xReconstructed(1,:));
        mse_pred_AE(i) = mse_pred;
figure(11);clf;plot(LossTrain(1:kk),'b*'); hold on; plot(LossValidation(1:kk),'g'); 
plot(mse_pred)
    
    end
    
% K-L divergence condition check 
% KL_divv_mean0p5D_M1p0  = mean(KL_divv) % Data is 0.5muT and Model is 1muT
% KL_divv_mean0p5D_M0p5  = abs(mean(KL_divv)) % Data is 0.5muT and Model is 0.5muT
% th = 0.015; % 0.025;   % threshold for 0.5uT data and 1uT data % respectively
% if KL_divv_mean0p5D_M0p5 >th; layers = net1p0_90_178_SingleStage.Layers; end

end
%% Save the model to use later for Prediction or Retraining

save('net1p0.mat','net1p0');

%%
load('net1p0.mat')
%% Prediction and MSE calculation with reference data
 XPred = XTrain(:,1:89); % Original Data
for j= 1:1:N-7
 

    xtest1 = XPred(j:j+7,1:89); 
    xtest(j:j+7,:)=awgn(xtest1,35,'measured'); % Addition of Gaussian Noise
xReconstructed(j:j+7,:) = predict(net1p0,xtest(j:j+7,:)); % Prediction 
mse_cal2(j,:)= mse(xtest1,xReconstructed);% 
end
 % figure,plot(mse_cal2)


% Display the plots
for i=1:1:N-7
    figure(31); plot(xtest(i,1:89),'m'); hold on; plot(xReconstructed(i,:),'b');
    plot((xtest(i,1:89)-xReconstructed(i,:)),'r.-');title('Elu Activation')
end

