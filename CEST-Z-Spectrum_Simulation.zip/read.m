clear;
% tt mean saturation power (uT)
tt_0p25uT_9p4T=0.25;
tt_0p5uT_9p4T=0.5;
tt_1uT_9p4T=1;
% pulse duration is the total saturation time (s)
pulseduration=5;  
i_SNR=2;  % add noise
gauss=100;
% create frequency offset
maxf=2000;
step=50;
% frequency offset of each pool
sep1_9p4T=3.6*400;  %amide
sep2_9p4T=3*400; %fast amine
sep3_9p4T=2*400  % creatine amine
sep4_9p4T=-1.6*400; % NOE at -1.6
sep5_9p4T=-3.3*400; % NOE at -3.3

% relaxation times 
R1S=1/1.5;
%R2S1=1/0.002;
R2S2=1/0.01;
R2S3=1/0.01;
R2S4=1/0.001;
%R2S5=1/0.0005;
R1W=1/1.5;
R2W=1/0.06;
R1M=1/1.5;
R2M=1/0.00005;

% apparent R1W
%R1W_obs=(R1W+fm*R1M)/(1+fm);

% Setting the Total number of offset points based on the step size

offset= -maxf:step:maxf;
k_9p4T=[-4000, -3500, -3000, -2500, offset, 2500, 3000,3500,4000];
k_9p4T=k_9p4T';
lent= length(k_9p4T);

% The concentration setting for some solutes
fs3=0.0003;
fs4=0.003;
% The exchange rate setting for some solutes
ksw3=500;
ksw4=50;
kmw=25;


num_fs1=6;%6;
num_fs2=1;%4;
num_fs5=1;%4;
num_fm=1;%5;
num_ksw1=1;%6;
num_ksw2=1;%2;%3;  
num_ksw5=1;%4;
num_R2S1=1;
num_R2S5=1;
aa_0p25uT_9p4T= zeros(lent,num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
% data augmentation by adding noise.
aa_0p25uT_9p4T_noise= zeros(lent,num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
aa_0p5uT_9p4T = zeros(lent,num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
aa_0p5uT_9p4T_noise = zeros(lent,num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
aa_1uT_9p4T = zeros(lent,num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
aa_1uT_9p4T_noise =zeros(lent,num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);


fs1_matrix = zeros(num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
fs2_matrix= zeros(num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
fs5_matrix =zeros(num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
ksw1_matrix =zeros(num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
ksw2_matrix =zeros(num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
ksw5_matrix =zeros(num_fs1,num_fs2,num_fs5, num_fm, num_ksw1,num_ksw2, num_ksw5);
kkk=0;

 % Run the loop for each variable that defines the pool parameters variation   
  
for ii_fs1=1:num_fs1
    fs1=0.0006+0.0002*(ii_fs1-1); % 0.0006 initial value + 0.0002 step size for each loop
  
    for ii_fs2=1:num_fs2
        fs2=0.002+0.003*(ii_fs2-1);% 0.002 0.0003
        for ii_fs5=1:num_fs5
            fs5=0.005+0.002*(ii_fs5-1); % 0.005+0.002
            for ii_fm=1:num_fm
                fm=0.03+0.03*(ii_fm-1); % 0.03
                
                for ii_ksw1=1:num_ksw1
                    ksw1=40+20*(ii_ksw1-1); % 40-->100 +20
                    for ii_ksw2=1:num_ksw2
                        ksw2=3000+1000*(ii_ksw2-1);
                        for ii_ksw5=1:num_ksw5
                            ksw5=10+5*(ii_ksw5-1); % 10
                            for ii_R2S1 = 1:num_R2S1
                                R2S1=1/(0.001+0.001*(ii_R2S1-1));
                                for ii_R2S5 = 1:num_R2S5
                                R2S5=1/(0.0003+0.0002*(ii_R2S5-1));

                            
                            % simulating Zspectrum with power of 0p25uT
                            satangle=tt_0p25uT_9p4T*42.6*360*pulseduration;
                            a25mspulse = runsteadysimgauss(ksw1, ksw2,ksw3, ksw4, ksw5, kmw, fs1, fs2, fs3,fs4, fs5, 1, fm, R1S, R2S1, R2S2, R2S3,R2S4, R2S5, R1W, R2W, R1M, R2M,sep1_9p4T*2*pi,sep2_9p4T*2*pi,sep3_9p4T*2*pi,sep4_9p4T*2*pi, sep5_9p4T*2*pi, pulseduration, gauss, satangle, 1, 2, 1, .00, 1, 1, k_9p4T*2*pi, 1);
                            aa_0p25uT_9p4T(:,ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=a25mspulse(:,6);
                            % data augmentation by adding noise.
                            aa_0p25uT_9p4T_noise(:,ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5) =sqrt((a25mspulse(:,6)+0.0015*0.25*(i_SNR)*randn(size(a25mspulse(:,6)))).^2+(0.0015*0.25*(i_SNR)*randn(size(a25mspulse(:,6)))).^2);
                            aa_0p25uT_9p4T_noise2(:,ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5) =sqrt((a25mspulse(:,6)+0.002*0.25*(i_SNR)*randn(size(a25mspulse(:,6)))).^2+(0.002*0.25*(i_SNR)*randn(size(a25mspulse(:,6)))).^2);
                                                 
                            
                            
                            % simulating Zspectrum with power of 0p5uT
                            satangle=tt_0p5uT_9p4T*42.6*360*pulseduration;
                            a25mspulse = runsteadysimgauss(ksw1, ksw2,ksw3, ksw4, ksw5, kmw, fs1, fs2, fs3,fs4, fs5, 1, fm, R1S, R2S1, R2S2, R2S3,R2S4, R2S5, R1W, R2W, R1M, R2M,sep1_9p4T*2*pi,sep2_9p4T*2*pi,sep3_9p4T*2*pi,sep4_9p4T*2*pi, sep5_9p4T*2*pi, pulseduration, gauss, satangle, 1, 2, 1, .00, 1, 1, k_9p4T*2*pi, 1);
                            aa_0p5uT_9p4T(:,ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=a25mspulse(:,6);
                            % data augmentation by adding noise.
                            aa_0p5uT_9p4T_noise(:,ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5) =sqrt((a25mspulse(:,6)+0.0015*0.5*(i_SNR)*randn(size(a25mspulse(:,6)))).^2+(0.0015*0.5*(i_SNR)*randn(size(a25mspulse(:,6)))).^2);
                            aa_0p5uT_9p4T_noise2(:,ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5) =sqrt((a25mspulse(:,6)+0.002*0.5*(i_SNR)*randn(size(a25mspulse(:,6)))).^2+(0.002*0.5*(i_SNR)*randn(size(a25mspulse(:,6)))).^2);
                             
                            
                            
                            % simulating Zspectrum with power of 1uT
                            satangle=tt_1uT_9p4T*42.6*360*pulseduration;
                            a25mspulse = runsteadysimgauss(ksw1, ksw2,ksw3, ksw4, ksw5, kmw, fs1, fs2, fs3,fs4, fs5, 1, fm, R1S, R2S1, R2S2, R2S3,R2S4, R2S5, R1W, R2W, R1M, R2M,sep1_9p4T*2*pi,sep2_9p4T*2*pi,sep3_9p4T*2*pi,sep4_9p4T*2*pi, sep5_9p4T*2*pi, pulseduration, gauss, satangle, 1, 2, 1, .00, 1, 1, k_9p4T*2*pi, 1);
                            aa_1uT_9p4T(:,ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=a25mspulse(:,6);
                            % data augmentation by adding noise.
                            aa_1uT_9p4T_noise(:,ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5) =sqrt((a25mspulse(:,6)+0.0015*(i_SNR)*randn(size(a25mspulse(:,6)))).^2+(0.0015*(i_SNR)*randn(size(a25mspulse(:,6)))).^2);
                            aa_1uT_9p4T_noise2(:,ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5) =sqrt((a25mspulse(:,6)+0.002*(i_SNR)*randn(size(a25mspulse(:,6)))).^2+(0.002*(i_SNR)*randn(size(a25mspulse(:,6)))).^2);
                            
                            
                            fs1_matrix(ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=fs1;
                            fs2_matrix(ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=fs2;
                            fs5_matrix(ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=fs5;
                            
                            ksw1_matrix(ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=ksw1;
                            ksw2_matrix(ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=ksw2;
                            ksw5_matrix(ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=ksw5;
                            r2s1_matrix(ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=1/R2S1;
                            r2s5_matrix(ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=1/R2S5;
                            mt_matrix(ii_fs1,ii_fs2,ii_fs5, ii_fm, ii_ksw1,ii_ksw2, ii_ksw5, ii_R2S1, ii_R2S5)=fm;


                                end
                           end
                        end                                  
                    end
                end
            end
        end
    end
    
end
%%
for ii=1:length(k_9p4T)
     aa_9p4T(ii,:,:,:,:,:,:,:,:,:)=aa_0p25uT_9p4T(ii,:,:,:,:,:,:,:,:,:,:,:);
    aa_9p4T(ii+length(k_9p4T),:,:,:,:,:,:,:,:,:)=aa_0p5uT_9p4T(ii,:,:,:,:,:,:,:,:,:);
    aa_9p4T(ii+2*length(k_9p4T),:,:,:,:,:,:,:,:,:)=aa_1uT_9p4T(ii,:,:,:,:,:,:,:,:,:);
    
    aa_9p4T_noise(ii,:,:,:,:,:,:,:,:,:)=aa_0p25uT_9p4T_noise(ii,:,:,:,:,:,:,:,:,:);
    aa_9p4T_noise(ii+length(k_9p4T),:,:,:,:,:,:,:,:,:)=aa_0p5uT_9p4T_noise(ii,:,:,:,:,:,:,:,:,:);
    aa_9p4T_noise(ii+2*length(k_9p4T),:,:,:,:,:,:,:,:,:)=aa_1uT_9p4T_noise(ii,:,:,:,:,:,:,:,:,:);

    aa_9p4T_noise2(ii,:,:,:,:,:,:,:,:,:)=aa_0p25uT_9p4T_noise2(ii,:,:,:,:,:,:,:,:,:);
    aa_9p4T_noise2(ii+length(k_9p4T),:,:,:,:,:,:,:,:,:)=aa_0p5uT_9p4T_noise2(ii,:,:,:,:,:,:,:,:,:);
    aa_9p4T_noise2(ii+2*length(k_9p4T),:,:,:,:,:,:,:,:,:)=aa_1uT_9p4T_noise2(ii,:,:,:,:,:,:,:,:,:);
 
end
%%
% input matrix: 
% output matrix: 
matrix_input(:,:)=reshape(aa_9p4T,  [length(k_9p4T')*3 num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5]);
matrix_noise_input(:,:)=reshape(aa_9p4T_noise,  [length(k_9p4T')*3 num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5]);
matrix_noise_input2(:,:)=reshape(aa_9p4T_noise2,  [length(k_9p4T')*3 num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5]);


matrix_output(:,1)=reshape(fs1_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);
matrix_output(:,2)=reshape(ksw1_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);
matrix_output(:,3)=reshape(r2s1_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);
matrix_output(:,4)=reshape(fs5_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);
matrix_output(:,5)=reshape(ksw5_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);
matrix_output(:,6)=reshape(r2s5_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);
matrix_output(:,7)=reshape(mt_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);
matrix_output(:,8)=reshape(fs2_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);
matrix_output(:,9)=reshape(ksw2_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);
% matrix_output(:,10)=reshape(NorT_matrix,  [num_fs1*num_fs2*num_fs5*num_fm*num_ksw1*num_ksw2*num_ksw5*ii_R2S1*ii_R2S5 1]);

% Saving the Data with and without Noise
%%
Cest_Data2 =[ matrix_input;matrix_output'];
Cest_Data2N =[ matrix_noise_input;matrix_output'];
Cest_Data2N2 =[ matrix_noise_input2;matrix_output'];
%
Cest_Data= [Cest_Data2]';
Cest_DataN=[Cest_Data2N]';
Cest_DataN2=[Cest_Data2N2]';
%%
Cest_Data = [ Cest_Data; Cest_DataN; Cest_DataN2];

% save('CEST_DataB1Variation2.mat','Cest_Data');
%%
 
%%
% % clear Cest_Data 
% 
for i=1:4
    kk = [i];%, Cest_Data(i,268:277)];
f=figure(4440), plot(Cest_Data(i,1:267)); hold on;title({'img no and params'},{num2str(kk)}); pause;
f.Position = [10 10 1590 800]; 
end
